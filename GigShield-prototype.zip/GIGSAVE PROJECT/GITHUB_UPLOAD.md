# Upload this whole project to GitHub

Everything you need is already in your project folder **`GIGSAVE PROJECT`**. You do **not** paste code into GitHub’s website file-by-file — you push the folder with Git (or upload a ZIP of the folder using GitHub’s web UI, though Git is recommended).

## What gets uploaded (repository layout)

```
GIGSAVE PROJECT/
├── .github/workflows/deploy-website.yml   # GitHub Pages workflow
├── .gitignore
├── .env.example                             # Safe template (copy to apps/api/.env locally)
├── docker-compose.yml
├── HOSTING.md
├── GITHUB_UPLOAD.md                         # This file
├── README.md
├── netlify.toml
├── vercel.json
├── package.json                             # npm workspaces (root)
├── website/                                 # Static site (hosting)
│   ├── index.html
│   ├── styles.css
│   └── script.js
└── apps/
    ├── api/                                 # Node + Prisma backend
    ├── admin/                               # Vite admin UI
    └── worker/                              # Vite worker UI
```

Do **not** commit `node_modules/` or `apps/api/.env` — they are ignored. After clone, run `npm install` and create `apps/api/.env` from `.env.example`.

---

## Option A — Git from your PC (recommended)

1. Install [Git](https://git-scm.com/downloads) if needed.

2. Open **PowerShell** or **Command Prompt** and run (adjust path if yours differs):

```powershell
cd "c:\Users\shukl\GIGSAVE PROJECT"
git init
git add .
git status
```

3. Commit:

```powershell
git commit -m "Initial commit: GigShield prototype"
```

4. On GitHub: **New repository** → name it e.g. `gigshield` → **Create repository** (no README if you already have one locally).

5. Connect and push (replace `YOUR_USER` and `YOUR_REPO`):

```powershell
git branch -M main
git remote add origin https://github.com/YOUR_USER/YOUR_REPO.git
git push -u origin main
```

If GitHub asks for login, use a **Personal Access Token** as the password (Settings → Developer settings → Personal access tokens), or use GitHub CLI `gh auth login`.

---

## Option B — GitHub Desktop

1. Install [GitHub Desktop](https://desktop.github.com/).
2. **File → Add local repository** → choose `c:\Users\shukl\GIGSAVE PROJECT`.
3. If not a repo yet, **create repository** there.
4. **Publish repository** to your GitHub account.

---

## Option C — ZIP upload (quick, not ideal for updates)

1. Zip the **`GIGSAVE PROJECT`** folder (exclude `node_modules` if present to keep size small).
2. GitHub does not accept drag-and-drop of a whole folder as a repo in one step; use **Option A** or **B** for a proper repo.  
   Alternatively: create an empty repo on GitHub, then use **uploading an existing file** only for small projects — for this codebase, **use Git push**.

---

## After the repo is on GitHub

1. **Secrets:** Never commit real `DATABASE_URL`, `JWT_SECRET`, or API keys. Use `apps/api/.env` locally only (ignored). For production, use GitHub **Secrets** or your host’s env vars.

2. **GitHub Pages:** Enable **Pages → GitHub Actions** (see `HOSTING.md`). The workflow in `.github/workflows/deploy-website.yml` deploys the `website/` folder.

3. **Clone on another machine:**

```bash
git clone https://github.com/YOUR_USER/YOUR_REPO.git
cd YOUR_REPO
npm install
```

---

## If something is missing

The “whole code” is **the entire `GIGSAVE PROJECT` directory** on disk — every file listed by your editor’s file tree. There is no separate single file that contains all code; Git uploads all tracked files in one push.
