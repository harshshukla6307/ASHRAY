const fallbackPlans = {
  basic: { id: "basic", name: "Basic", priceWeekly: 29, maxCoverage: 600 },
  standard: { id: "standard", name: "Standard", priceWeekly: 49, maxCoverage: 1200 },
  pro: { id: "pro", name: "Pro", priceWeekly: 89, maxCoverage: 2500 },
};

const planCards = document.getElementById("planCards");
const planSelect = document.getElementById("plan");
const enrollBtn = document.getElementById("enrollBtn");
const runBtn = document.getElementById("runBtn");
const result = document.getElementById("result");
const timeline = document.getElementById("timeline");
const signalGrid = document.getElementById("signalGrid");
const decision = document.getElementById("decision");
const statusText = document.getElementById("statusText");
const payoutHistory = document.getElementById("payoutHistory");

let currentWorkerId = null;
let plans = { ...fallbackPlans };

function renderPlans(selected = "standard") {
  planCards.innerHTML = "";
  Object.entries(plans).forEach(([id, p]) => {
    const div = document.createElement("div");
    div.className = `plan ${selected === id ? "active" : ""}`;
    div.innerHTML = `
      <h3>${p.name}</h3>
      <div class="price">INR ${p.priceWeekly}/week</div>
      <div class="muted">Max coverage INR ${p.maxCoverage}</div>
    `;
    div.addEventListener("click", () => {
      planSelect.value = id;
      renderPlans(id);
    });
    planCards.appendChild(div);
  });
}

function apiBase() {
  return (document.getElementById("apiBaseUrl").value || "http://127.0.0.1:3001").replace(/\/$/, "");
}

async function request(path, options = {}) {
  const res = await fetch(`${apiBase()}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : {};
  if (!res.ok) throw new Error(typeof data.error === "string" ? data.error : JSON.stringify(data));
  return data;
}

async function loadPlansFromApi() {
  try {
    const list = await request("/public/plans");
    plans = list.reduce((acc, p) => {
      acc[p.id] = p;
      return acc;
    }, {});
    renderPlans(planSelect.value || "standard");
    statusText.textContent = `Connected to backend: ${apiBase()}`;
  } catch (_e) {
    plans = { ...fallbackPlans };
    renderPlans(planSelect.value || "standard");
    statusText.textContent = "Backend unreachable. Using fallback plan display only.";
  }
}

function renderTimeline(lines) {
  timeline.innerHTML = "";
  lines.forEach((step) => {
    const row = document.createElement("div");
    row.className = "timeline-item";
    row.textContent = step;
    timeline.appendChild(row);
  });
}

function renderPayoutHistory(payouts) {
  payoutHistory.innerHTML = "<h3>Worker payout history</h3>";
  if (!payouts || payouts.length === 0) {
    payoutHistory.innerHTML += '<p class="muted">No payouts yet.</p>';
    return;
  }
  payouts.forEach((p) => {
    const div = document.createElement("div");
    div.className = "history-item";
    div.innerHTML = `
      <strong>INR ${p.amount}</strong> · ${p.status}<br/>
      <span class="muted">${p.reason}</span><br/>
      <span class="muted">${new Date(p.createdAt).toLocaleString()}</span>
    `;
    payoutHistory.appendChild(div);
  });
}

async function enrollWorker() {
  const payload = {
    name: document.getElementById("workerName").value || "Worker",
    phone: document.getElementById("phone").value || undefined,
    city: document.getElementById("city").value || "City",
    zone: document.getElementById("zone").value || "Zone",
    dailyEstimate: Number(document.getElementById("dailyIncome").value || 700),
    planId: planSelect.value,
  };
  const data = await request("/public/worker/enroll", {
    method: "POST",
    body: JSON.stringify(payload),
  });
  currentWorkerId = data.worker.id;
  statusText.textContent = `Worker enrolled: ${data.worker.name} (${data.worker.id.slice(0, 8)}...)`;
  const dashboard = await request(`/public/worker/${currentWorkerId}`);
  renderPayoutHistory(dashboard.payouts);
  return data.worker;
}

enrollBtn.addEventListener("click", async () => {
  try {
    enrollBtn.disabled = true;
    await enrollWorker();
  } catch (e) {
    statusText.textContent = `Enrollment failed: ${(e).message}`;
  } finally {
    enrollBtn.disabled = false;
  }
});

runBtn.addEventListener("click", async () => {
  try {
    runBtn.disabled = true;
    if (!currentWorkerId) await enrollWorker();

    const eventType = document.getElementById("eventType").value;
    const severity = document.getElementById("severity").value;
    const sim = await request("/public/simulate", {
      method: "POST",
      body: JSON.stringify({
        workerId: currentWorkerId,
        type: eventType,
        severity,
      }),
    });

    const signals = sim.result?.signals || {};
    const payout = sim.latestPayout;
    const verified = Boolean(sim.result?.verified);
    const status = payout?.status || "blocked (unverified)";
    const amount = payout?.amount || 0;
    const className = !verified ? "bad" : status === "completed" ? "good" : "warn";

    renderTimeline([
      `Worker ${sim.worker.name} active in ${sim.worker.zone}, ${sim.worker.city}`,
      `${eventType} disruption detected with ${severity} severity`,
      `Multi-signal verification ${verified ? "passed" : "failed"}`,
      `Payout status: ${status}`,
    ]);

    signalGrid.innerHTML = `
      <div class="signal">Rainfall: <strong>${signals.rainfallMm ?? "-"}</strong></div>
      <div class="signal">AQI: <strong>${signals.aqi ?? "-"}</strong></div>
      <div class="signal">Heat Index: <strong>${signals.heatIndex ?? "-"}</strong></div>
      <div class="signal">Road Risk: <strong>${signals.roadClosureProb ?? "-"}</strong></div>
      <div class="signal">Store Open: <strong>${typeof signals.storeOpen === "boolean" ? (signals.storeOpen ? "Yes" : "No") : "-"}</strong></div>
      <div class="signal">Signal Score: <strong>${signals.aggregateScore ?? "-"}/100</strong></div>
    `;

    decision.innerHTML = `
      <h3 class="${className}">Final payout: INR ${amount}</h3>
      <p class="muted">UPI ref: ${payout?.upiRef || "n/a"} · fraud tier: ${payout?.fraudTier || "n/a"}</p>
    `;

    const dashboard = await request(`/public/worker/${currentWorkerId}`);
    renderPayoutHistory(dashboard.payouts);
    result.hidden = false;
  } catch (e) {
    statusText.textContent = `Simulation failed: ${(e).message}`;
  } finally {
    runBtn.disabled = false;
  }
});

planSelect.addEventListener("change", () => renderPlans(planSelect.value));

function applyHostedApiDefaults() {
  const input = document.getElementById("apiBaseUrl");
  const params = new URLSearchParams(window.location.search);
  const q = params.get("api");
  if (q) {
    input.value = q.replace(/\/$/, "");
    return;
  }
  const meta = document.querySelector('meta[name="gigshield-api"]');
  const m = meta?.getAttribute("content")?.trim();
  if (m) input.value = m.replace(/\/$/, "");
}

document.getElementById("apiBaseUrl").addEventListener("change", () => {
  currentWorkerId = null;
  loadPlansFromApi();
});
applyHostedApiDefaults();
loadPlansFromApi();