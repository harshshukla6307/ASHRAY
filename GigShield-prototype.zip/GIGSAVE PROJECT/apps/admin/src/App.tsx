import { useCallback, useEffect, useState } from "react";

const API = import.meta.env.VITE_API_URL ?? "http://localhost:3001";
const ADMIN_KEY = import.meta.env.VITE_ADMIN_KEY ?? "dev-admin-key";

const adminHeaders = {
  "Content-Type": "application/json",
  "X-Admin-Key": ADMIN_KEY,
} as const;

type Overview = { users: number; events: number; payouts: number };

type Worker = {
  id: string;
  name: string;
  phone: string;
  zone: string;
  city: string;
  subscriptions: { plan: { name: string } }[];
  _count: { payouts: number };
};

type Event = {
  id: string;
  type: string;
  zone: string;
  severity: string;
  verified: boolean;
  signalScore: number | null;
  createdAt: string;
};

type Payout = {
  id: string;
  amount: number;
  status: string;
  reason: string;
  user: { name: string; phone: string; zone: string };
};

export default function App() {
  const [overview, setOverview] = useState<Overview | null>(null);
  const [workers, setWorkers] = useState<Worker[]>([]);
  const [events, setEvents] = useState<Event[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [err, setErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    setErr(null);
    const req = (path: string) =>
      fetch(`${API}${path}`, { headers: adminHeaders }).then(async (r) => {
        const data = await r.json();
        if (!r.ok) throw new Error(JSON.stringify(data));
        return data;
      });
    const [o, w, e, p] = await Promise.all([
      req("/admin/overview"),
      req("/admin/workers"),
      req("/admin/events"),
      req("/admin/payouts"),
    ]);
    if (!o || typeof o.users !== "number") throw new Error("Admin API unreachable");
    setOverview(o as Overview);
    setWorkers(w as Worker[]);
    setEvents(e as Event[]);
    setPayouts(p as Payout[]);
  }, []);

  useEffect(() => {
    load().catch((e) => setErr((e as Error).message));
  }, [load]);

  return (
    <div className="shell">
      <header>
        <h1>GigShield</h1>
        <p className="muted">Operations · fraud review · demo triggers</p>
        <button type="button" className="btn ghost" onClick={() => load()}>
          Refresh
        </button>
      </header>

      {err && <div className="banner">{err}</div>}

      {overview && (
        <section className="grid3">
          <div className="stat">
            <div className="label">Workers</div>
            <div className="num">{overview.users}</div>
          </div>
          <div className="stat">
            <div className="label">Events</div>
            <div className="num">{overview.events}</div>
          </div>
          <div className="stat">
            <div className="label">Payouts</div>
            <div className="num">{overview.payouts}</div>
          </div>
        </section>
      )}

      <SimulateForm
        api={API}
        onDone={() => load().catch(() => undefined)}
      />

      <section>
        <h2>Recent disruptions</h2>
        <div className="table cols-5">
          <div className="row head">
            <span>Time</span>
            <span>Type</span>
            <span>Zone</span>
            <span>Verified</span>
            <span>Score</span>
          </div>
          {events.map((ev) => (
            <div key={ev.id} className="row">
              <span className="mono">{new Date(ev.createdAt).toLocaleString()}</span>
              <span>{ev.type}</span>
              <span>{ev.zone}</span>
              <span>{ev.verified ? "yes" : "no"}</span>
              <span>{ev.signalScore ?? "—"}</span>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2>Workers</h2>
        <div className="table cols-4">
          <div className="row head">
            <span>Name</span>
            <span>Zone</span>
            <span>Plan</span>
            <span>Payouts</span>
          </div>
          {workers.map((w) => (
            <div key={w.id} className="row">
              <span>{w.name}</span>
              <span>{w.zone}</span>
              <span>{w.subscriptions[0]?.plan.name ?? "—"}</span>
              <span>{w._count.payouts}</span>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2>Recent payouts</h2>
        <div className="table cols-4">
          <div className="row head">
            <span>Worker</span>
            <span>Zone</span>
            <span>Amount</span>
            <span>Status</span>
          </div>
          {payouts.map((p) => (
            <div key={p.id} className="row">
              <span>{p.user.name}</span>
              <span>{p.user.zone}</span>
              <span>₹{p.amount.toLocaleString("en-IN")}</span>
              <span>{p.status}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function SimulateForm({
  api,
  onDone,
}: {
  api: string;
  onDone: () => void;
}) {
  const [type, setType] = useState("rain");
  const [zone, setZone] = useState("Sector-29");
  const [city, setCity] = useState("Gurugram");
  const [severity, setSeverity] = useState("high");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  async function run() {
    setBusy(true);
    setResult(null);
    try {
      const res = await fetch(`${api}/admin/simulate`, {
        method: "POST",
        headers: adminHeaders,
        body: JSON.stringify({ type, zone, city, severity }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(JSON.stringify(data));
      setResult(JSON.stringify(data, null, 2));
      onDone();
    } catch (e) {
      setResult((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <section className="card">
      <h2>Demo: trigger disruption</h2>
      <p className="muted">
        Creates a disruption record, runs multi-signal verification, and credits payouts
        for workers in the zone with an active weekly plan.
      </p>
      <div className="form">
        <label>
          Type
          <select value={type} onChange={(e) => setType(e.target.value)}>
            <option value="rain">Heavy rain</option>
            <option value="aqi">AQI spike</option>
            <option value="heat">Extreme heat</option>
            <option value="closure">Road closure</option>
            <option value="store_shutdown">Dark store closed</option>
          </select>
        </label>
        <label>
          Zone (must match worker profile)
          <input value={zone} onChange={(e) => setZone(e.target.value)} />
        </label>
        <label>
          City (optional)
          <input value={city} onChange={(e) => setCity(e.target.value)} />
        </label>
        <label>
          Severity
          <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
            <option value="low">Low</option>
            <option value="medium">Medium</option>
            <option value="high">High</option>
          </select>
        </label>
        <button type="button" className="btn primary" disabled={busy} onClick={run}>
          {busy ? "Running…" : "Run simulation"}
        </button>
      </div>
      {result && (
        <pre className="out">{result}</pre>
      )}
    </section>
  );
}
