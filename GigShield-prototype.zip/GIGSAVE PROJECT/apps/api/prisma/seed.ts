import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  await prisma.plan.upsert({
    where: { id: "basic" },
    create: {
      id: "basic",
      name: "Basic",
      priceWeekly: 29,
      maxCoverage: 600,
    },
    update: {},
  });
  await prisma.plan.upsert({
    where: { id: "standard" },
    create: {
      id: "standard",
      name: "Standard",
      priceWeekly: 49,
      maxCoverage: 1200,
    },
    update: {},
  });
  await prisma.plan.upsert({
    where: { id: "pro" },
    create: {
      id: "pro",
      name: "Pro",
      priceWeekly: 89,
      maxCoverage: 2500,
    },
    update: {},
  });
  console.log("Seeded plans.");
}

main()
  .then(() => prisma.$disconnect())
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
