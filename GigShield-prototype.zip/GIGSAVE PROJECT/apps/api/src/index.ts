import "dotenv/config";
import express from "express";
import cors from "cors";
import { authRouter } from "./routes/auth.js";
import { workerRouter } from "./routes/worker.js";
import { adminRouter } from "./routes/admin.js";
import { publicRouter } from "./routes/public.js";

const app = express();
app.use(
  cors({
    origin: true,
    credentials: true,
  }),
);
app.use(express.json());

app.get("/health", (_req, res) => {
  res.json({ ok: true, service: "gigshield-api" });
});

app.use("/auth", authRouter);
app.use("/admin", adminRouter);
app.use("/public", publicRouter);
app.use("/", workerRouter);

const port = Number(process.env.PORT ?? 3001);
app.listen(port, () => {
  console.log(`GigShield API http://localhost:${port}`);
});
