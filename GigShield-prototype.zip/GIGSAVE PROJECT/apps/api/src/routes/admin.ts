import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { adminMiddleware } from "../middleware/auth.js";
import { processDisruptionPayouts } from "../services/payoutEngine.js";

const router = Router();
router.use(adminMiddleware);

router.get("/overview", async (_req, res) => {
  const [users, events, payouts] = await Promise.all([
    prisma.user.count(),
    prisma.disruptionEvent.count(),
    prisma.payout.count(),
  ]);
  res.json({ users, events, payouts });
});

router.get("/workers", async (_req, res) => {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: {
      subscriptions: {
        where: { status: "active" },
        take: 1,
        include: { plan: true },
      },
      _count: { select: { payouts: true } },
    },
  });
  res.json(users);
});

router.get("/events", async (_req, res) => {
  const events = await prisma.disruptionEvent.findMany({
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  res.json(events);
});

router.get("/payouts", async (_req, res) => {
  const payouts = await prisma.payout.findMany({
    orderBy: { createdAt: "desc" },
    take: 50,
    include: { user: { select: { name: true, phone: true, zone: true } } },
  });
  res.json(payouts);
});

const simulateBody = z.object({
  type: z.enum(["rain", "aqi", "heat", "closure", "store_shutdown"]),
  zone: z.string().min(1),
  city: z.string().optional(),
  severity: z.enum(["low", "medium", "high"]),
});

router.post("/simulate", async (req, res) => {
  const parsed = simulateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }
  const { type, zone, city, severity } = parsed.data;

  const event = await prisma.disruptionEvent.create({
    data: {
      type,
      zone,
      city: city ?? null,
      severity,
      verified: false,
    },
  });

  const result = await processDisruptionPayouts({
    eventId: event.id,
    type,
    zone,
    city,
    severity,
  });

  res.json({ event, result });
});

export { router as adminRouter };
