import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { signToken, type AuthedRequest } from "../middleware/auth.js";

const router = Router();

const registerBody = z.object({
  phone: z.string().min(10),
  password: z.string().min(4),
  name: z.string().min(1),
  city: z.string().min(1),
  zone: z.string().min(1),
  dailyEstimate: z.number().int().min(100).max(5000).optional(),
});

router.post("/register", async (req, res) => {
  const parsed = registerBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }
  const { phone, password, name, city, zone, dailyEstimate } = parsed.data;
  const existing = await prisma.user.findUnique({ where: { phone } });
  if (existing) {
    res.status(409).json({ error: "Phone already registered" });
    return;
  }
  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: {
      phone,
      passwordHash,
      name,
      city,
      zone,
      dailyEstimate: dailyEstimate ?? 700,
      wallet: { create: { balanceCents: 0 } },
    },
  });
  const token = signToken(user.id);
  res.json({
    token,
    user: {
      id: user.id,
      phone: user.phone,
      name: user.name,
      city: user.city,
      zone: user.zone,
      dailyEstimate: user.dailyEstimate,
    },
  });
});

const loginBody = z.object({
  phone: z.string(),
  password: z.string(),
});

router.post("/login", async (req, res) => {
  const parsed = loginBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }
  const user = await prisma.user.findUnique({ where: { phone: parsed.data.phone } });
  if (!user || !(await bcrypt.compare(parsed.data.password, user.passwordHash))) {
    res.status(401).json({ error: "Invalid credentials" });
    return;
  }
  const token = signToken(user.id);
  res.json({
    token,
    user: {
      id: user.id,
      phone: user.phone,
      name: user.name,
      city: user.city,
      zone: user.zone,
      dailyEstimate: user.dailyEstimate,
    },
  });
});

export { router as authRouter };
