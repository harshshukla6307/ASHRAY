import { Router } from "express";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { processDisruptionPayouts } from "../services/payoutEngine.js";

const router = Router();

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  const day = x.getDay();
  const diff = x.getDate() - day + (day === 0 ? -6 : 1);
  x.setDate(diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

router.get("/plans", async (_req, res) => {
  const plans = await prisma.plan.findMany({ orderBy: { priceWeekly: "asc" } });
  res.json(plans);
});

const enrollBody = z.object({
  name: z.string().min(1),
  phone: z.string().min(10).optional(),
  city: z.string().min(1),
  zone: z.string().min(1),
  dailyEstimate: z.number().int().min(100).max(5000),
  planId: z.enum(["basic", "standard", "pro"]),
});

router.post("/worker/enroll", async (req, res) => {
  const parsed = enrollBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }
  const data = parsed.data;
  const weekStart = startOfWeek(new Date());
  const phone =
    data.phone ??
    `demo${Date.now().toString().slice(-8)}${Math.floor(Math.random() * 90 + 10)}`;

  const passwordHash = await bcrypt.hash("demo-password", 10);
  const user = await prisma.user.upsert({
    where: { phone },
    create: {
      phone,
      passwordHash,
      name: data.name,
      city: data.city,
      zone: data.zone,
      dailyEstimate: data.dailyEstimate,
      wallet: { create: { balanceCents: 0 } },
    },
    update: {
      name: data.name,
      city: data.city,
      zone: data.zone,
      dailyEstimate: data.dailyEstimate,
    },
  });

  await prisma.subscription.updateMany({
    where: { userId: user.id, status: "active", weekStart },
    data: { status: "replaced" },
  });

  const subscription = await prisma.subscription.create({
    data: {
      userId: user.id,
      planId: data.planId,
      weekStart,
      status: "active",
    },
    include: { plan: true },
  });

  res.json({
    worker: {
      id: user.id,
      name: user.name,
      phone: user.phone,
      city: user.city,
      zone: user.zone,
      dailyEstimate: user.dailyEstimate,
    },
    subscription,
  });
});

const simulateBody = z.object({
  workerId: z.string().min(1),
  type: z.enum(["rain", "aqi", "heat", "closure", "store_shutdown"]),
  severity: z.enum(["low", "medium", "high"]),
});

router.post("/simulate", async (req, res) => {
  const parsed = simulateBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }

  const worker = await prisma.user.findUnique({
    where: { id: parsed.data.workerId },
  });
  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }

  const event = await prisma.disruptionEvent.create({
    data: {
      type: parsed.data.type,
      zone: worker.zone,
      city: worker.city,
      severity: parsed.data.severity,
      verified: false,
    },
  });

  const result = await processDisruptionPayouts({
    eventId: event.id,
    type: parsed.data.type,
    zone: worker.zone,
    city: worker.city,
    severity: parsed.data.severity,
  });

  const latestPayout = await prisma.payout.findFirst({
    where: { userId: worker.id },
    orderBy: { createdAt: "desc" },
  });

  res.json({ event, result, worker, latestPayout });
});

router.get("/worker/:id", async (req, res) => {
  const id = req.params.id;
  const [worker, payouts, wallet, subscription] = await Promise.all([
    prisma.user.findUnique({ where: { id } }),
    prisma.payout.findMany({
      where: { userId: id },
      orderBy: { createdAt: "desc" },
      take: 20,
    }),
    prisma.gigSaveWallet.findUnique({ where: { userId: id } }),
    prisma.subscription.findFirst({
      where: { userId: id, status: "active", weekStart: startOfWeek(new Date()) },
      include: { plan: true },
    }),
  ]);

  if (!worker) {
    res.status(404).json({ error: "Worker not found" });
    return;
  }

  res.json({
    worker: {
      id: worker.id,
      name: worker.name,
      city: worker.city,
      zone: worker.zone,
      phone: worker.phone,
      dailyEstimate: worker.dailyEstimate,
    },
    activePlan: subscription?.plan ?? null,
    gigSaveCents: wallet?.balanceCents ?? 0,
    payouts,
  });
});

export { router as publicRouter };
