import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { authMiddleware, type AuthedRequest } from "../middleware/auth.js";
import { accrueGigSavePercent } from "../services/payoutEngine.js";

const router = Router();

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  const day = x.getDay();
  const diff = x.getDate() - day + (day === 0 ? -6 : 1);
  x.setDate(diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

router.get("/me", authMiddleware, async (req: AuthedRequest, res) => {
  const userId = req.userId!;
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: {
      wallet: true,
      subscriptions: {
        where: { status: "active", weekStart: startOfWeek(new Date()) },
        include: { plan: true },
        take: 1,
      },
    },
  });
  if (!user) {
    res.status(404).json({ error: "Not found" });
    return;
  }
  res.json({
    id: user.id,
    name: user.name,
    city: user.city,
    zone: user.zone,
    dailyEstimate: user.dailyEstimate,
    gigSaveCents: user.wallet?.balanceCents ?? 0,
    activePlan: user.subscriptions[0]?.plan ?? null,
    subscription: user.subscriptions[0] ?? null,
  });
});

router.get("/plans", async (_req, res) => {
  const plans = await prisma.plan.findMany({ orderBy: { priceWeekly: "asc" } });
  res.json(plans);
});

const subscribeBody = z.object({
  planId: z.enum(["basic", "standard", "pro"]),
});

router.post("/subscribe", authMiddleware, async (req: AuthedRequest, res) => {
  const parsed = subscribeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }
  const userId = req.userId!;
  const weekStart = startOfWeek(new Date());

  await prisma.subscription.updateMany({
    where: { userId, status: "active", weekStart },
    data: { status: "replaced" },
  });

  const sub = await prisma.subscription.create({
    data: {
      userId,
      planId: parsed.data.planId,
      weekStart,
      status: "active",
    },
    include: { plan: true },
  });

  res.json(sub);
});

router.get("/payouts", authMiddleware, async (req: AuthedRequest, res) => {
  const list = await prisma.payout.findMany({
    where: { userId: req.userId! },
    orderBy: { createdAt: "desc" },
    take: 50,
  });
  res.json(list);
});

const gigsaveBody = z.object({
  earnedToday: z.number().int().min(0),
});

router.post("/gigsave/accrue", authMiddleware, async (req: AuthedRequest, res) => {
  const parsed = gigsaveBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.flatten() });
    return;
  }
  await accrueGigSavePercent(req.userId!, parsed.data.earnedToday);
  const w = await prisma.gigSaveWallet.findUnique({ where: { userId: req.userId! } });
  res.json({ balanceCents: w?.balanceCents ?? 0 });
});

export { router as workerRouter };
