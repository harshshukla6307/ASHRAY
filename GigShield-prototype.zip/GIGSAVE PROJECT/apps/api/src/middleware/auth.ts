import type { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";

export type AuthedRequest = Request & { userId?: string };

const secret = () => process.env.JWT_SECRET ?? "dev-secret-change-me";

export function signToken(userId: string) {
  return jwt.sign({ sub: userId }, secret(), { expiresIn: "30d" });
}

export function authMiddleware(
  req: AuthedRequest,
  res: Response,
  next: NextFunction,
) {
  const h = req.headers.authorization;
  const token = h?.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  try {
    const p = jwt.verify(token, secret()) as { sub: string };
    req.userId = p.sub;
    next();
  } catch {
    res.status(401).json({ error: "Invalid token" });
  }
}

export function adminMiddleware(req: Request, res: Response, next: NextFunction) {
  const key = req.headers["x-admin-key"];
  const expected = process.env.ADMIN_KEY ?? "dev-admin-key";
  if (key !== expected) {
    res.status(403).json({ error: "Forbidden" });
    return;
  }
  next();
}
