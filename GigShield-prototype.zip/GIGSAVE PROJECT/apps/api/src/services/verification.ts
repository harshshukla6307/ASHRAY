export type SignalBundle = {
  rainfallMm: number;
  aqi: number;
  heatIndex: number;
  roadClosureProb: number;
  storeOpen: boolean;
  aggregateScore: number;
};

function rand(min: number, max: number) {
  return min + Math.random() * (max - min);
}

export function mockSignalsForDisruption(type: string, severity: string): SignalBundle {
  const sev = severity === "high" ? 1 : severity === "medium" ? 0.7 : 0.45;

  const rainfallMm =
    type === "rain" ? rand(25, 80) * sev : rand(0, 5);
  const aqi =
    type === "aqi" ? rand(350, 480) * sev : rand(80, 180);
  const heatIndex =
    type === "heat" ? rand(42, 48) : rand(32, 38);
  const roadClosureProb =
    type === "closure" ? rand(0.6, 0.95) : rand(0.05, 0.2);
  const storeOpen = type === "store_shutdown" ? false : Math.random() > 0.15;

  const parts = [
    rainfallMm > 20 ? 30 : 10,
    aqi > 300 ? 28 : 12,
    heatIndex > 41 ? 22 : 8,
    roadClosureProb * 20,
    storeOpen ? 10 : 0,
  ];
  const aggregateScore = Math.min(
    100,
    Math.round(parts.reduce((a, b) => a + b, 0) + rand(5, 25)),
  );

  return {
    rainfallMm: Math.round(rainfallMm * 10) / 10,
    aqi: Math.round(aqi),
    heatIndex: Math.round(heatIndex * 10) / 10,
    roadClosureProb: Math.round(roadClosureProb * 100) / 100,
    storeOpen,
    aggregateScore,
  };
}

export function passesMultiSignalCheck(signals: SignalBundle): boolean {
  const checks = [
    signals.rainfallMm >= 15 || signals.aqi >= 300 || signals.heatIndex >= 42,
    signals.aggregateScore >= 48,
    signals.storeOpen === false || signals.roadClosureProb >= 0.35,
  ];
  const passCount = checks.filter(Boolean).length;
  return passCount >= 2;
}
