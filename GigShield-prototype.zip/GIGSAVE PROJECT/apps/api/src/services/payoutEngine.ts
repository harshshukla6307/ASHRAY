import type { Plan, User } from "@prisma/client";
import { prisma } from "../lib/prisma.js";
import { publishEvent } from "../lib/redis.js";
import {
  mockSignalsForDisruption,
  passesMultiSignalCheck,
} from "./verification.js";

type Severity = "low" | "medium" | "high";

function severityMultiplier(s: string): number {
  if (s === "high") return 1;
  if (s === "medium") return 0.65;
  return 0.4;
}

function mockFraudTier(user: User): "clear" | "review" | "suspicious" {
  const h = hashString(user.id);
  if (h % 17 === 0) return "suspicious";
  if (h % 7 === 0) return "review";
  return "clear";
}

function hashString(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i);
  return Math.abs(h);
}

export async function processDisruptionPayouts(input: {
  eventId: string;
  type: string;
  zone: string;
  city?: string;
  severity: Severity;
}) {
  const signals = mockSignalsForDisruption(input.type, input.severity);
  const verified = passesMultiSignalCheck(signals);

  await prisma.disruptionEvent.update({
    where: { id: input.eventId },
    data: {
      verified,
      signalScore: signals.aggregateScore,
      summary: JSON.stringify({ signals }),
    },
  });

  if (!verified) {
    await publishEvent("gigshield:events", {
      type: "disruption_unverified",
      eventId: input.eventId,
      signals,
    });
    return { verified: false, payouts: [], signals };
  }

  const weekStart = startOfWeek(new Date());

  const subs = await prisma.subscription.findMany({
    where: {
      status: "active",
      weekStart,
      user: { zone: input.zone },
    },
    include: { user: true, plan: true },
  });

  const payouts: { userId: string; amount: number; status: string }[] = [];

  for (const sub of subs) {
    const { user, plan } = sub;
    const tier = mockFraudTier(user);
    const base = Math.min(
      plan.maxCoverage,
      Math.round(user.dailyEstimate * severityMultiplier(input.severity)),
    );

    let amount = base;
    let status = "completed";
    let fraudTier: string | undefined = tier;

    if (tier === "suspicious") {
      amount = Math.round(base * 0.35);
      status = "partial_review";
    } else if (tier === "review") {
      amount = Math.round(base * 0.72);
      status = "partial_review";
    }

    const upiRef = `UPI-MOCK-${Date.now()}-${user.id.slice(-4)}`;

    await prisma.payout.create({
      data: {
        userId: user.id,
        amount,
        status,
        reason: `${input.type} disruption in ${input.zone}`,
        upiRef: status === "completed" || status === "partial_review" ? upiRef : null,
        fraudTier,
      },
    });

    payouts.push({ userId: user.id, amount, status });

    await publishEvent("gigshield:events", {
      type: "payout",
      userId: user.id,
      amount,
      status,
      eventId: input.eventId,
    });
  }

  return { verified: true, payouts, signals };
}

function startOfWeek(d: Date): Date {
  const x = new Date(d);
  const day = x.getDay();
  const diff = x.getDate() - day + (day === 0 ? -6 : 1);
  x.setDate(diff);
  x.setHours(0, 0, 0, 0);
  return x;
}

export async function accrueGigSavePercent(userId: string, earnedToday: number) {
  const pct = 0.05;
  const add = Math.round(earnedToday * pct * 100);
  if (add <= 0) return;
  await prisma.gigSaveWallet.upsert({
    where: { userId },
    create: { userId, balanceCents: add },
    update: { balanceCents: { increment: add } },
  });
}
