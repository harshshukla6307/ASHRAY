import Redis from "ioredis";

const url = process.env.REDIS_URL ?? "redis://127.0.0.1:6379";

let client: Redis | null = null;

export function getRedis(): Redis | null {
  if (client) return client;
  try {
    client = new Redis(url, { maxRetriesPerRequest: 2 });
    return client;
  } catch {
    return null;
  }
}

export async function publishEvent(channel: string, payload: unknown) {
  const r = getRedis();
  if (!r) return;
  try {
    await r.publish(channel, JSON.stringify(payload));
  } catch {
    /* optional in prototype */
  }
}
