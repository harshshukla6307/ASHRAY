import { useCallback, useEffect, useState } from "react";
import { api } from "./api";

type User = {
  id: string;
  phone: string;
  name: string;
  city: string;
  zone: string;
  dailyEstimate: number;
};

type Me = {
  id: string;
  name: string;
  city: string;
  zone: string;
  dailyEstimate: number;
  gigSaveCents: number;
  activePlan: { id: string; name: string; maxCoverage: number; priceWeekly: number } | null;
  subscription: { id: string } | null;
};

type Plan = {
  id: string;
  name: string;
  priceWeekly: number;
  maxCoverage: number;
};

type Payout = {
  id: string;
  amount: number;
  status: string;
  reason: string;
  upiRef: string | null;
  fraudTier: string | null;
  createdAt: string;
};

type Screen = "home" | "plans" | "activity" | "gigsave";

export default function App() {
  const [token, setToken] = useState<string | null>(() =>
    localStorage.getItem("gs_token"),
  );
  const [screen, setScreen] = useState<Screen>("home");
  const [me, setMe] = useState<Me | null>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const loadMe = useCallback(async () => {
    const m = await api<Me>("/me");
    setMe(m);
  }, []);

  useEffect(() => {
    if (!token) return;
    setLoading(true);
    setErr(null);
    loadMe()
      .catch((e: Error) => setErr(e.message))
      .finally(() => setLoading(false));
  }, [token, loadMe]);

  const refreshPayouts = useCallback(async () => {
    const list = await api<Payout[]>("/payouts");
    setPayouts(list);
  }, []);

  useEffect(() => {
    if (!token || screen !== "activity") return;
    refreshPayouts().catch((e: Error) => setErr(e.message));
  }, [token, screen, refreshPayouts]);

  useEffect(() => {
    if (!token || screen !== "plans") return;
    api<Plan[]>("/plans")
      .then(setPlans)
      .catch((e: Error) => setErr(e.message));
  }, [token, screen]);

  async function handleLogout() {
    localStorage.removeItem("gs_token");
    setToken(null);
    setMe(null);
    setScreen("home");
  }

  if (!token) {
    return (
      <div className="shell">
        <AuthFlow
          onAuthed={(t, u) => {
            localStorage.setItem("gs_token", t);
            setToken(t);
            setMe({
              id: u.id,
              name: u.name,
              city: u.city,
              zone: u.zone,
              dailyEstimate: u.dailyEstimate,
              gigSaveCents: 0,
              activePlan: null,
              subscription: null,
            });
          }}
        />
      </div>
    );
  }

  return (
    <div className="shell">
      <header className="topbar">
        <div>
          <div className="brand">GigShield</div>
          <div className="sub">Income protection</div>
        </div>
        <button type="button" className="btn ghost sm" onClick={handleLogout}>
          Log out
        </button>
      </header>

      {err && (
        <div className="banner error" role="alert">
          {err}
        </div>
      )}

      <main className="main">
        {loading && !me && <div className="muted">Loading…</div>}

        {screen === "home" && me && (
          <HomeView
            me={me}
            onRefresh={async () => {
              setErr(null);
              try {
                await loadMe();
              } catch (e) {
                setErr((e as Error).message);
              }
            }}
          />
        )}

        {screen === "plans" && (
          <PlansView
            plans={plans}
            onPick={async (planId) => {
              setErr(null);
              try {
                await api("/subscribe", {
                  method: "POST",
                  body: JSON.stringify({ planId }),
                });
                await loadMe();
                setScreen("home");
              } catch (e) {
                setErr((e as Error).message);
              }
            }}
          />
        )}

        {screen === "activity" && (
          <ActivityView payouts={payouts} onRefresh={refreshPayouts} />
        )}

        {screen === "gigsave" && me && <GigSaveView me={me} onUpdate={loadMe} />}
      </main>

      <nav className="tabbar">
        <button
          type="button"
          className={screen === "home" ? "active" : ""}
          onClick={() => setScreen("home")}
        >
          Shield
        </button>
        <button
          type="button"
          className={screen === "plans" ? "active" : ""}
          onClick={() => setScreen("plans")}
        >
          Plans
        </button>
        <button
          type="button"
          className={screen === "activity" ? "active" : ""}
          onClick={() => setScreen("activity")}
        >
          Activity
        </button>
        <button
          type="button"
          className={screen === "gigsave" ? "active" : ""}
          onClick={() => setScreen("gigsave")}
        >
          GigSave
        </button>
      </nav>
    </div>
  );
}

function AuthFlow({
  onAuthed,
}: {
  onAuthed: (token: string, user: User) => void;
}) {
  const [mode, setMode] = useState<"login" | "register">("register");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("Ravi");
  const [city, setCity] = useState("Gurugram");
  const [zone, setZone] = useState("Sector-29");
  const [busy, setBusy] = useState(false);
  const [localErr, setLocalErr] = useState<string | null>(null);

  async function submit() {
    setBusy(true);
    setLocalErr(null);
    try {
      if (mode === "register") {
        const r = await api<{ token: string; user: User }>("/auth/register", {
          method: "POST",
          body: JSON.stringify({
            phone,
            password,
            name,
            city,
            zone,
            dailyEstimate: 700,
          }),
        });
        onAuthed(r.token, r.user);
      } else {
        const r = await api<{ token: string; user: User }>("/auth/login", {
          method: "POST",
          body: JSON.stringify({ phone, password }),
        });
        onAuthed(r.token, r.user);
      }
    } catch (e) {
      setLocalErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="auth">
      <div className="hero">
        <div className="badge">Prototype</div>
        <h1>GigShield</h1>
        <p>
          If rain, AQI, or shutdowns stop your day — you still get covered.
          No claims. Instant payout to UPI.
        </p>
      </div>

      {localErr && <div className="banner error">{localErr}</div>}

      <div className="card">
        <div className="segmented">
          <button
            type="button"
            className={mode === "register" ? "on" : ""}
            onClick={() => setMode("register")}
          >
            New account
          </button>
          <button
            type="button"
            className={mode === "login" ? "on" : ""}
            onClick={() => setMode("login")}
          >
            Log in
          </button>
        </div>

        <label>
          Phone
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="9876543210"
            inputMode="tel"
          />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="••••"
          />
        </label>

        {mode === "register" && (
          <>
            <label>
              Name
              <input value={name} onChange={(e) => setName(e.target.value)} />
            </label>
            <label>
              City
              <input value={city} onChange={(e) => setCity(e.target.value)} />
            </label>
            <label>
              Work zone
              <input
                value={zone}
                onChange={(e) => setZone(e.target.value)}
                placeholder="e.g. Sector-29"
              />
            </label>
          </>
        )}

        <button
          type="button"
          className="btn primary"
          disabled={busy}
          onClick={submit}
        >
          {busy ? "Please wait…" : mode === "register" ? "Create account" : "Log in"}
        </button>
      </div>
    </div>
  );
}

function HomeView({
  me,
  onRefresh,
}: {
  me: Me;
  onRefresh: () => Promise<void>;
}) {
  const plan = me.activePlan;
  const covered = plan ? `Up to ₹${plan.maxCoverage.toLocaleString("en-IN")}` : "No plan this week";

  return (
    <div className="stack">
      <section className="card hero-card">
        <div className="row-between">
          <div>
            <div className="label">Hi {me.name.split(" ")[0]}</div>
            <h2>{me.zone}</h2>
            <p className="muted">{me.city} · est. ₹{me.dailyEstimate}/day</p>
          </div>
          <button type="button" className="btn ghost sm" onClick={onRefresh}>
            Refresh
          </button>
        </div>
        <div className="pill-row">
          <span className="pill ok">Monitoring on</span>
          {plan && <span className="pill">{plan.name} plan</span>}
        </div>
      </section>

      <section className="card">
        <h3>Coverage</h3>
        <p className="big">{covered}</p>
        <p className="muted small">
          We cross-check rain, AQI, heat, and route signals before any payout — never
          one source alone.
        </p>
      </section>

      <section className="card">
        <h3>GigSave buffer</h3>
        <p className="big">₹{(me.gigSaveCents / 100).toFixed(2)}</p>
        <p className="muted small">
          5% of daily earnings (simulated) builds a small cushion for slow days.
        </p>
      </section>
    </div>
  );
}

function PlansView({
  plans,
  onPick,
}: {
  plans: Plan[];
  onPick: (id: string) => void;
}) {
  return (
    <div className="stack">
      <p className="muted">
        Weekly pricing — tap to activate for this week (prototype).
      </p>
      {plans.map((p) => (
        <button
          key={p.id}
          type="button"
          className="card plan-card"
          onClick={() => onPick(p.id)}
        >
          <div className="row-between">
            <div>
              <h3>{p.name}</h3>
              <p className="muted">Max ₹{p.maxCoverage.toLocaleString("en-IN")}</p>
            </div>
            <div className="price">₹{p.priceWeekly}/wk</div>
          </div>
        </button>
      ))}
    </div>
  );
}

function ActivityView({
  payouts,
  onRefresh,
}: {
  payouts: Payout[];
  onRefresh: () => Promise<void>;
}) {
  return (
    <div className="stack">
      <div className="row-between">
        <h2>Payouts</h2>
        <button type="button" className="btn ghost sm" onClick={() => onRefresh()}>
          Refresh
        </button>
      </div>
      {payouts.length === 0 && (
        <p className="muted">No payouts yet. When a verified disruption hits your zone, a UPI credit appears here.</p>
      )}
      {payouts.map((p) => (
        <div key={p.id} className="card">
          <div className="row-between">
            <div>
              <div className="amount">₹{p.amount.toLocaleString("en-IN")}</div>
              <div className="muted small">{p.reason}</div>
            </div>
            <span className={`tag ${p.status}`}>{p.status}</span>
          </div>
          {p.upiRef && <div className="mono small muted">{p.upiRef}</div>}
          {p.fraudTier && p.fraudTier !== "clear" && (
            <div className="note">
              Fraud model: {p.fraudTier} — partial amount + review (prototype).
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function GigSaveView({
  me,
  onUpdate,
}: {
  me: Me;
  onUpdate: () => Promise<void>;
}) {
  const [earned, setEarned] = useState("700");
  const [msg, setMsg] = useState<string | null>(null);

  async function accrue() {
    setMsg(null);
    try {
      await api<{ balanceCents: number }>("/gigsave/accrue", {
        method: "POST",
        body: JSON.stringify({ earnedToday: Number(earned) || 0 }),
      });
      await onUpdate();
      setMsg("Saved 5% of today’s earnings (simulated).");
    } catch (e) {
      setMsg((e as Error).message);
    }
  }

  return (
    <div className="stack">
      <section className="card">
        <h3>Balance</h3>
        <p className="big">₹{(me.gigSaveCents / 100).toFixed(2)}</p>
        <p className="muted small">
          Not insurance — a self-buffer that pairs with GigShield for bigger shocks.
        </p>
      </section>
      <section className="card">
        <h3>Simulate a workday</h3>
        <label>
          Earnings today (₹)
          <input value={earned} onChange={(e) => setEarned(e.target.value)} inputMode="numeric" />
        </label>
        <button type="button" className="btn primary" onClick={accrue}>
          Apply 5% to GigSave
        </button>
        {msg && <p className="muted small">{msg}</p>}
      </section>
    </div>
  );
}
