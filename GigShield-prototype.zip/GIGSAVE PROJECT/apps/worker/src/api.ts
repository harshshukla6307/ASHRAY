const API = import.meta.env.VITE_API_URL ?? "http://localhost:3001";

function authHeader(): HeadersInit {
  const t = localStorage.getItem("gs_token");
  return t ? { Authorization: `Bearer ${t}` } : {};
}

export async function api<T>(
  path: string,
  init?: RequestInit,
): Promise<T> {
  const res = await fetch(`${API}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...authHeader(),
      ...(init?.headers ?? {}),
    },
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const err = (data as { error?: string })?.error ?? res.statusText;
    throw new Error(typeof err === "string" ? err : JSON.stringify(err));
  }
  return data as T;
}
