# Hosting the GigShield website

The marketing + demo site lives in **`website/`** (static HTML/CSS/JS). You can host it on any static host.

## Before you go live

1. **Deploy the API** somewhere public (Render, Railway, Fly.io, your VPS, etc.) with:
   - PostgreSQL + optional Redis
   - `DATABASE_URL`, `JWT_SECRET`, `ADMIN_KEY`, `PORT`, `CORS` is already permissive in dev (`origin: true`).

2. **Point the site at your API** using one of:
   - **Query string:** `https://YOUR_SITE/?api=https://YOUR_API_HOST`
   - **Meta tag:** edit `website/index.html` and set  
     `<meta name="gigshield-api" content="https://YOUR_API_HOST" />`  
     (no trailing slash)

3. **CORS:** The API must allow your site’s origin. The prototype uses `cors({ origin: true })`, which reflects the request origin in many setups — verify in production and restrict to your domain if needed.

---

## Netlify

1. Push this repo to GitHub/GitLab/Bitbucket.
2. [Netlify](https://www.netlify.com/) → Add new site → Import from Git.
3. Build command: leave empty or `echo ok`.
4. Publish directory: **`website`** (or rely on root `netlify.toml`).
5. Deploy.

Your site URL will look like `https://random-name.netlify.app`.

---

## Vercel

1. [Vercel](https://vercel.com/) → New Project → Import repo.
2. **Root Directory:** set to **`website`** *or* use the repo root with `vercel.json` (`outputDirectory: website` — confirm in Vercel UI; some versions want Root Directory = `website`).
3. Framework preset: **Other** / no framework.
4. Deploy.

---

## Cloudflare Pages

1. Cloudflare Dashboard → Pages → Create project → Connect Git.
2. Build command: empty.
3. Build output directory: **`website`**.

---

## GitHub Pages

1. Push to `main` or `master`.
2. Repo → **Settings** → **Pages** → **Build and deployment** → Source: **GitHub Actions**.
3. The workflow `.github/workflows/deploy-website.yml` uploads the `website/` folder.

Site URL: `https://<user>.github.io/<repo>/` — relative asset paths (`styles.css`, `script.js`) work as deployed.

---

## Quick test without Git

- **Netlify Drop:** drag the **`website`** folder onto [app.netlify.com/drop](https://app.netlify.com/drop).

---

## API URL reminder

Hosted pages cannot call `http://127.0.0.1:3001`. Use your deployed API HTTPS URL in the **API base URL** field on the page, or the meta tag / `?api=` query parameter above.
