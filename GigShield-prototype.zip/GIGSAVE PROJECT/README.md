# GigShield prototype

Real-time income protection for Q-commerce delivery partners — **Phase 1** demo: onboarding, weekly plans, multi-signal verification (mock), automatic payouts (mock UPI), GigSave accrual, and an admin panel to trigger disruption simulations.

## Stack

- **API**: Node.js (Express) + TypeScript + Prisma + PostgreSQL + Redis
- **Worker UI**: Vite + React (mobile-first web; swap to React Native later without changing the API)
- **Admin UI**: Vite + React

## Prerequisites

- Node.js 20+ and npm
- Docker (for Postgres + Redis), or your own instances

## Setup

1. Start databases:

   ```bash
   docker compose up -d
   ```

2. Install dependencies (from repo root):

   ```bash
   npm install
   ```

3. Configure API env (default `apps/api/.env` is committed for local dev — change secrets for anything public):

   - `DATABASE_URL`, `REDIS_URL`, `JWT_SECRET`, `ADMIN_KEY`, `PORT`

4. Push schema and seed plans:

   ```bash
   npm run db:push
   npm run db:seed
   ```

## Run

In three terminals:

```bash
npm run dev:api
```

```bash
npm run dev:admin
```

```bash
npm run dev:worker
```

- Worker app: http://localhost:5174  
- Admin: http://localhost:5173  
- API: http://localhost:3001  

Optional: set `VITE_API_URL=http://localhost:3001` for the Vite apps if you proxy or host elsewhere.

## Demo flow

1. Open the **worker** app, register (default zone **Sector-29** matches the admin simulator).
2. Choose a **weekly plan** on the Plans tab.
3. Open **Admin** → **Demo: trigger disruption** → use type **rain**, zone **Sector-29**, severity **high** → Run.
4. Back in the worker app, **Activity** shows payouts (amount may be partial if the mock fraud tier is `review` / `suspicious`).

Redis is optional: if Redis is down, the API still runs; pub/sub events are skipped.

## Team & repo

Add your team and GitHub link in this README when ready.

## Host the website (Netlify, Vercel, GitHub Pages)

See **[HOSTING.md](HOSTING.md)** for step-by-step deployment of the `website/` folder and how to point the demo at a public API URL.

## Upload the whole project to GitHub

See **[GITHUB_UPLOAD.md](GITHUB_UPLOAD.md)** for commands to push this entire folder as one repository (nothing to copy-paste file by file).

## Browser-only website (no npm needed)

If you want a quick prototype that runs directly in a browser:

1. Open `website/index.html` in your browser, or
2. Serve the `website` folder with any static server.

This website includes:
- GigShield concept page
- Weekly plan cards
- Interactive disruption simulator
- Automatic payout decision preview based on verification + fraud tier

To use the proper backend with this website:

1. Start infra and API:
   - `docker compose up -d`
   - `npm install`
   - `npm run db:push`
   - `npm run db:seed`
   - `npm run dev:api`
2. Open `website/index.html` (or serve `website/` statically).
3. In the simulator, keep API URL as `http://127.0.0.1:3001`.

Backend website endpoints used:
- `GET /public/plans`
- `POST /public/worker/enroll`
- `POST /public/simulate`
- `GET /public/worker/:id`
